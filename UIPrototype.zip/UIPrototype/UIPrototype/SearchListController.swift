//
//  SearchListController.swift
//  UIPrototype
//
//  Created by 缪哲文 on 16/2/24.
//  Copyright © 2016年 缪哲文. All rights reserved.
//

import UIKit

class SearchListController: UITableView {

    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */

}
