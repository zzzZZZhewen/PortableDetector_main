//
//  StatusViewController.swift
//  UIPrototype
//
//  Created by 缪哲文 on 16/2/21.
//  Copyright © 2016年 缪哲文. All rights reserved.
//

import UIKit
import AVFoundation

class StatusViewController: UIViewController {
    
    var cameraController: CameraController?
    var recognizer: RecognizePlate?
    
    @IBOutlet weak var balanceAIcon: UIImageView!
    @IBOutlet weak var balanceBIcon: UIImageView!
    @IBOutlet weak var instrumentIcon: UIImageView!
    @IBOutlet weak var automobileIcon: UIImageView!
    @IBOutlet weak var cameraPreview: UIView!
    @IBOutlet weak var lastRecordPlate: UIImageView!

    @IBOutlet weak var plateTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setIcons()
        self.setCamera()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        if let previewLayer = cameraController?.videoPreviewLayer {
            previewLayer.frame = cameraPreview.bounds
            previewLayer.connection.videoOrientation = AVCaptureVideoOrientation(rawValue: UIDevice.currentDevice().orientation.rawValue)!
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - event
    
    
    @IBAction func startButtonTappedInside(sender: AnyObject) {
        self.cameraController?.shoot()
    }
    
    
    // MARK: - private
    
    func setIcons() {
        self.balanceAIcon.tintColor = UIColor(red: 236/255, green: 63/255, blue: 140/255, alpha: 1.0)
        self.balanceBIcon.tintColor = UIColor(red: 236/255, green: 63/255, blue: 140/255, alpha: 1.0)
        self.instrumentIcon.tintColor = UIColor(red: 57/255, green: 177/255, blue: 198/255, alpha: 1.0)
        self.automobileIcon.tintColor = UIColor(red: 57/255, green: 177/255, blue: 198/255, alpha: 1.0)
    }
    
    func setCamera() {
        cameraController = CameraController(delegate: self)
        if let previewLayer = cameraController?.videoPreviewLayer {
            previewLayer.frame = cameraPreview.bounds
            cameraPreview.layer.addSublayer(previewLayer)
        }
        recognizer = RecognizePlate(delegate: self)
    }
    
}


extension StatusViewController: CameraControllerDelegate {
    func cameraController(cameraController: CameraController, didShootSucceededWithImageData imageData: NSData) {
        
        let queue =  dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)
        
        dispatch_async(queue) { [weak self]() -> Void in
            if let elf = self {
                let path = TNiOSHelper.getDocumentsPath().stringByAppendingString("/t.jpg")
                print(path)
                imageData.writeToFile(path, atomically: false)
                elf.recognizer?.recognizePlate(path)
            }

        }
    }
}

extension StatusViewController: RecognizePlateDelegate {
    func didFinishRecognizePlate(recognizeResult:IdentifyResult) {
        
        let queue = dispatch_get_main_queue()
        dispatch_async(queue) { [weak self]() -> Void in
            if let elf = self {
                if recognizeResult.getError() == "Success" {
                    print(recognizeResult.getString())
                    elf.plateTextField.text = recognizeResult.getString()
                    elf.lastRecordPlate.image = UIImage(data: recognizeResult.getImage())
                } else {
                     elf.plateTextField.text =  "hh"
                }
            }
        }
    }
}
