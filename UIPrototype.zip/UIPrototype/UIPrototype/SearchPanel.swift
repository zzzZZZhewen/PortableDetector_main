//
//  SearchPanelController.swift
//  UIPrototype
//
//  Created by 缪哲文 on 16/2/24.
//  Copyright © 2016年 缪哲文. All rights reserved.
//

import UIKit

protocol SearchPanelControllerDelegate: class {
    
}

class SearchPanelController: NSObject {

    weak var delegate: SearchPanelControllerDelegate?
    var tableView: UITableView!
    
    init(delegate: SearchPanelControllerDelegate, tableView: UITableView) {
        super.init()
        self.delegate = delegate
        self.tableView = tableView
    }
}

extension SearchPanelController: UITableViewDelegate {
    
}

//extension SearchPanelController: UITableViewDataSource {
//    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
//        return 1
//    }
//    
//    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        if section == 1 && datePickerVisible {
//            return 3
//        } else {
//            return super.tableView(tableView, numberOfRowsInSection: section)
//        }
//    }
//    
//    
//    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
//        let id = "textInputTableCellID"
//        
//    }
//}


